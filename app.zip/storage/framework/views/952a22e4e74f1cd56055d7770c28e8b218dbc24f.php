<?php if (isset($component)) { $__componentOriginal2fc6fc46242716bcbf134cce645937967fada248 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\StudentLayout::class, []); ?>
<?php $component->withName('student-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('List Hewan')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div>
        <div class="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8">
            <?php if($message = Session::get('success')): ?>
                <div class="bg-white rounded-md shadow-lg p-5 mb-2">
                    <div class="alert alert-success">
                        <p><?php echo e($message); ?></p>
                    </div>
                </div>
            <?php endif; ?>
            <div class="bg-white rounded-md shadow-lg p-5">
                
                <div class="overflow-auto">
                    <table id="table" class="table-auto">
                        <thead class="text-xs font-semibold uppercase text-gray-400 bg-gray-50">
                            <tr>
                                <th class="p-2 whitespace-nowrap">
                                    <div class="font-semibold text-center">Action</div>
                                </th>
                                <th class="p-2 whitespace-nowrap">
                                    <div class="font-semibold text-left">Nama Hewan</div>
                                </th>
                                <th class="p-2 whitespace-nowrap">
                                    <div class="font-semibold text-left">Jenis Hewan</div>
                                </th>
                                <th class="p-2 whitespace-nowrap">
                                    <div class="font-semibold text-left">Harga Hewan</div>
                                </th>
                                <th class="p-2 whitespace-nowrap">
                                    <div class="font-semibold text-left">Modal Hewan</div>
                                </th>
                                <th class="p-2 whitespace-nowrap">
                                    <div class="font-semibold text-left">Kontrak Hewan</div>
                                </th>
                                <th class="p-2 whitespace-nowrap">
                                    <div class="font-semibold text-left">Target Berat Hewan</div>
                                </th>
                                <th class="p-2 whitespace-nowrap">
                                    <div class="font-semibold text-left">Status Hewan</div>
                                </th>
                                <th class="p-2 whitespace-nowrap">
                                    <div class="font-semibold text-left">Gambar</div>
                                </th>
                                <th class="p-2 whitespace-nowrap">
                                    <div class="font-semibold text-left">Pengadas</div>
                                </th>
                            </tr>
                        </thead>

                        <tbody class="text-sm divide-y divide-gray-100">
                            <!-- record 1 -->
                            <?php $__currentLoopData = $hewans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hewan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="p-2 whitespace-nowrap">
                                        <div class="flex justify-center">
                                            <form action="<?php echo e(route('admin.hewans.edit', $hewan->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('GET'); ?>
                                                <button type="submit" class="p-2 font-medium text-lg">
                                                    <i class="fa-solid fa-pen-to-square"></i>
                                                </button>
                                            </form>

                                            <form id="delete-form<?php echo e($hewan->id); ?>"
                                                action="<?php echo e(route('admin.hewans.destroy', $hewan->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>

                                            <button type="button" class="p-2 font-medium text-lg"
                                                onclick="confirmationDeleteRekening(<?php echo e($hewan->id); ?>);">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </button>

                                        </div>
                                    </td>
                                    <td class="p-2 whitespace-nowrap">
                                        <div class="text-left">
                                            <?php echo e($hewan->nama_hewan); ?>

                                        </div>
                                    </td>
                                    <td class="p-2 whitespace-nowrap">
                                        <div class="text-left">
                                            <?php echo e($hewan->jenis_hewan); ?>

                                        </div>
                                    </td>
                                    <td class="p-2 whitespace-nowrap">
                                        <div class="text-left">
                                            Rp.<?php echo e(number_format($hewan->harga_hewan)); ?>

                                        </div>
                                    </td>
                                    <td class="p-2 whitespace-nowrap">
                                        <div class="text-left">
                                            Rp.<?php echo e(number_format($hewan->modal_hewan)); ?>

                                        </div>
                                    </td>
                                    <td class="p-2 whitespace-nowrap">
                                        <div class="text-left">
                                            <?php echo e($hewan->kontrak_hewan); ?>

                                        </div>
                                    </td>
                                    <td class="p-2 whitespace-nowrap">
                                        <div class="text-left">
                                            <?php echo e($hewan->target_berat_hewan); ?> Kg
                                        </div>
                                    </td>
                                    <td class="p-2 whitespace-nowrap">
                                        <div class="text-left">
                                            <?php if($hewan->status_hewan == 0): ?>
                                                <p class="p-2 bg-yellow-300 rounded-sm">Belum dimodalkan</p>
                                            <?php elseif($hewan->status_hewan == 1): ?>
                                                <p class="p-2 bg-gray-400 rounded-sm">Proses Konfirmasi</p>
                                            <?php elseif($hewan->status_hewan == 2): ?>
                                                <p class="p-2 bg-gray-400 rounded-sm">Belum siap jual</p>
                                            <?php elseif($hewan->status_hewan == 3): ?>
                                                <p class="p-2 bg-blue-400 rounded-sm">Siap jual</p>
                                            <?php elseif($hewan->status_hewan == 4): ?>
                                                <p class="p-2 bg-green-400 rounded-sm">Terjual</p>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td class="p-2 whitespace-nowrap">
                                        <div class="text-left">
                                            <a class="border-blue-500 border-2 text-blue-500 font-semibold p-2 rounded-sm"
                                                href="/photo_hewan/<?php echo e($hewan->gambar); ?>" target="_blank">Lihat
                                                Gambar</a>
                                        </div>
                                    </td>
                                    <td class="p-2 whitespace-nowrap">
                                        <div class="text-left">
                                            <?php echo e($hewan->id_pengadas); ?>

                                        </div>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <script type="text/javascript">
                    $(function() {
                        var table = $('#table').DataTable({});
                    });
                </script>
                
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2fc6fc46242716bcbf134cce645937967fada248)): ?>
<?php $component = $__componentOriginal2fc6fc46242716bcbf134cce645937967fada248; ?>
<?php unset($__componentOriginal2fc6fc46242716bcbf134cce645937967fada248); ?>
<?php endif; ?>
<?php /**PATH C:\Users\widny\OneDrive\Documents\study\smart-farming\resources\views/pemodal/hewans/index.blade.php ENDPATH**/ ?>