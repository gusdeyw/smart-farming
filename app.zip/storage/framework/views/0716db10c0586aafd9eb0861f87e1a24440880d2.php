<?php if (isset($component)) { $__componentOriginal2fc6fc46242716bcbf134cce645937967fada248 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\StudentLayout::class, []); ?>
<?php $component->withName('student-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Proyek Pendanaan')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div>
        <div class="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8">
            <div class="bg-white rounded-md shadow-lg p-5">
                
                <div class="grid grid-cols-12 gap-5">
                    <?php $__currentLoopData = $hewans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hewan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div
                            class="col-span-12 md:col-span-4 bg-white drop-shadow-none hover:drop-shadow-md transition ease-in-out duration-300 rounded-md overflow-hidden shadow-lg">
                            <div class="bg-full bg-cover py-32 mb-2"
                                style="background-image: url('<?php echo e(asset('photo_hewan/' . $hewan->gambar)); ?>');"></div>
                            <div class="p-3">
                                <h2 class="font-bold mb-2 leading-relaxed"><?php echo e($hewan->nama_hewan); ?> </h2>
                                <p class=" font-semibold mb-2 leading-relaxed">Modal:
                                    Rp.<?php echo e(number_format($hewan->modal_hewan)); ?></p>
                                <p class=" font-semibold mb-2 leading-relaxed">Harga Jual:
                                    Rp.<?php echo e(number_format($hewan->harga_hewan)); ?></p>
                                <form action="<?php echo e(route('pemodal.items.update', $hewan->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <button type="submit"
                                        class="text-sm font-semibold py-2 px-4 rounded bg-blue-300 leading-relaxed mb-2 hover:text-black transition ease-in-out duration-300">Pilih</button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2fc6fc46242716bcbf134cce645937967fada248)): ?>
<?php $component = $__componentOriginal2fc6fc46242716bcbf134cce645937967fada248; ?>
<?php unset($__componentOriginal2fc6fc46242716bcbf134cce645937967fada248); ?>
<?php endif; ?>
<?php /**PATH C:\Users\widny\OneDrive\Documents\study\smart-farming\resources\views/pemodal/items/index.blade.php ENDPATH**/ ?>